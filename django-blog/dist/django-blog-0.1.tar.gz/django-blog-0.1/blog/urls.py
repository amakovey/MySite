"""myblog URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from . import views
from django.urls import path
app_name = 'blog'
urlpatterns = [
   	url(r'^$', views.index, name ='index'),
	url('all/', views.all, name ='all'),
	url('history/', views.history, name ='history'),
	url('signin/', views.signin, name ='signin'),
	url('register/', views.register, name ='register'),
	url('signout/', views.signout, name='signout'),
	url('newpost/', views.new_post, name='newpost'),
	url('lk/', views.lk, name='lk'),
	url('post/(?P<post_id>[0-9]+)', views.post, name ='post'),
	]
